var searchData=
[
  ['ladderbuttonconfig_63',['LadderButtonConfig',['../classace__button_1_1LadderButtonConfig.html',1,'ace_button::LadderButtonConfig'],['../classace__button_1_1LadderButtonConfig.html#a4d1169f4324af804afb75b4eddf7dcb8',1,'ace_button::LadderButtonConfig::LadderButtonConfig()']]]
];
